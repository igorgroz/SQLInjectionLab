const jwt = require("jsonwebtoken");
const jwksClient = require("jwks-rsa");

const ISSUER = process.env.JWT_ISSUER;
const AUDIENCE = process.env.JWT_AUDIENCE;
const TENANT_ID = process.env.ENTRA_TENANT_ID;

const client = jwksClient({
  jwksUri: `https://login.microsoftonline.com/${TENANT_ID}/discovery/v2.0/keys`,
});

function getKey(header, callback) {
  client.getSigningKey(header.kid, function (err, key) {
    if (err) return callback(err);
    const signingKey = key.getPublicKey();
    callback(null, signingKey);
  });
}

function requireJwt(req, res, next) {
  const auth = req.headers.authorization || "";

  if (!auth.startsWith("Bearer ")) {
    return res.status(401).json({ error: "missing_bearer_token" });
  }

  const token = auth.slice("Bearer ".length);

  jwt.verify(
    token,
    getKey,
    {
      algorithms: ["RS256"],
      issuer: ISSUER || undefined,
      audience: AUDIENCE || undefined,
      clockTolerance: 5,
    },
    (err, claims) => {
      if (err) {
        return res.status(401).json({ error: "invalid_token", detail: err.message });
      }

      req.user = {
        sub: claims.sub,
        roles: claims.roles || [],
        scp: claims.scp ? claims.scp.split(" ") : [],
      };

      return next();
    }
  );
}

function requireScope(scope) {
  return (req, res, next) => {
    const scopes = req.user?.scp || [];
    if (!scopes.includes(scope)) {
      return res.status(403).json({ error: "insufficient_scope" });
    }
    next();
  };
}

module.exports = { requireJwt, requireScope };